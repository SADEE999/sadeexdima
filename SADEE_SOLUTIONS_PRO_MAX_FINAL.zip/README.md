# SADEE SOLUTIONS — Store + Separate Admin

This is the upgraded GitHub Pages + Supabase version of the SADEE SOLUTIONS online store.

## Customer website
- Dark/red SADEE SOLUTIONS design
- Showcase video
- Live products from Supabase
- Search + category filter
- Product detail popup
- BUY NOW → WhatsApp +94 76 847 2404
- Customer name/phone are optional
- A lightweight order record is created in Supabase before WhatsApp opens
- Responsive phone layout

## Separate admin panel
The admin panel is intentionally separate from the customer UI:

`https://YOUR-GITHUB-USERNAME.github.io/YOUR-REPO/admin/`

The public store no longer shows an ADMIN button. Open `/admin/` directly when you want the private control center.

Admin features:
- Supabase Auth login
- Admin verification through `is_admin()` RPC
- Add / edit / delete products
- Change name, category, price, price note, description, features
- Upload product images to Supabase Storage
- Featured / hidden / active controls
- Search and filter
- Order records
- Live counts and refresh

## Supabase setup
1. Open Supabase SQL Editor.
2. Run `supabase.sql` once.
3. In Authentication → Users, make sure `sadeeXdima@gmail.com` exists and has a password.
4. `public.admin_users` is seeded with that email by the SQL file.
5. Login at `/admin/`.

## Important
- `config.js` contains only the browser-safe publishable key.
- Never put a Supabase service_role/secret key in frontend files.
- The customer BUY button records the order and then opens WhatsApp. It does not claim that payment was completed.

## GitHub Pages
The included `.github/workflows/deploy.yml` deploys the already-extracted website directly. It does NOT extract a ZIP.

Set GitHub Pages → Source to **GitHub Actions**.
