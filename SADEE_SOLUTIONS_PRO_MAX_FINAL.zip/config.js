// Browser-safe Supabase configuration.
// NEVER place a service_role/secret key in this file.
window.SUPABASE_URL = "https://cojrwjytgzxgjyzhnays.supabase.co";
window.SUPABASE_ANON_KEY = "sb_publishable_ve_c8o_QxnzRtxpAhGjhEg_ZUkOIDo-";
window.WHATSAPP_NUMBER = "94768472404";

window.EZ_CASH_NUMBER = "0760625028";
window.WHATSAPP_CHANNEL = "https://whatsapp.com/channel/0029VbE4clL9WtC8Acr91m01";
